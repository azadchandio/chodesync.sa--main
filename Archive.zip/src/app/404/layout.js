export default function ErrorLayout({ children }) {
  return <>{children}</>;
} 