import { Manrope } from 'next/font/google';
import Script from 'next/script';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles.css';
import Header from './components/Header';
import Footer from './components/Footer';

const manrope = Manrope({ subsets: ['latin'] });

export const metadata = {
  title: {
    default: 'Assistify',
    template: '%s | Assistify',
  },
  description: 'AI Startup and Technology Template',
  metadataBase: new URL('https://your-domain.com'),
  icons: [
    {
      rel: 'icon',
      url: '/favicon-16x16.png',
      sizes: '16x16',
      type: 'image/png',
    },
    {
      rel: 'icon',
      url: '/favicon-32x32.png',
      sizes: '32x32',
      type: 'image/png',
    },
  ],
  openGraph: {
    title: 'Assistify',
    description: 'AI Startup and Technology Template',
    siteName: 'Assistify',
    locale: 'en_US',
    type: 'website',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <Script strategy="afterInteractive" id="microsoft-clarity">
          {`
            (function(c,l,a,r,i,t,y){
                c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
                t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
                y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
            })(window, document, "clarity", "script", "p1nfykbzy6");
          `}
        </Script>
      </head>
      <body className={manrope.className}>
        <Header />
        <main> {children}</main>
        <Footer />
      </body>
    </html>
  );
}
