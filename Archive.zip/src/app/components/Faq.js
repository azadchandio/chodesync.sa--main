import React, { useState } from 'react';

export default function Faq() {
  const [activeIndex, setActiveIndex] = useState(0);

  const handleAccordionClick = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqData = [
    {
      question: "What is the limit on creating assistants?",
      answer: "Create as many assistants as you need! Enjoy unlimited flexibility by connecting each assistant to unique integrations and data sources. This allows them to cater to various teams, employees, or specific use cases seamlessly, with no restrictions."
    },
    {
      question: "Is it possible to control the data accessible to an assistant?",
      answer: "Create as many assistants as you need! Enjoy unlimited flexibility by connecting each assistant to unique integrations and data sources. This allows them to cater to various teams, employees, or specific use cases seamlessly, with no restrictions."
    },
    {
      question: "Is it possible to personalize my assistants chat page?",
      answer: "Create as many assistants as you need! Enjoy unlimited flexibility by connecting each assistant to unique integrations and data sources. This allows them to cater to various teams, employees, or specific use cases seamlessly, with no restrictions."
    },
    {
      question: "Whats the time frame for setting up and launching the assistant?",
      answer: "Create as many assistants as you need! Enjoy unlimited flexibility by connecting each assistant to unique integrations and data sources. This allows them to cater to various teams, employees, or specific use cases seamlessly, with no restrictions."
    },
    {
      question: "How customizable is the AI assistants interface and functionality?",
      answer: "Create as many assistants as you need! Enjoy unlimited flexibility by connecting each assistant to unique integrations and data sources. This allows them to cater to various teams, employees, or specific use cases seamlessly, with no restrictions."
    }
  ];

  return (
    <div className="mx-auto faq-area mx-850 mtb-192">
      <div className="container">
        <div data-aos="fade-up" data-aos-duration="1000">
          <div className="row">
            <div className="col-md-12">
              <h2 className="title-2">
                Frequently Asked <span>Questions</span>
              </h2>
              <div className="accordion" id="accordionInner">
                {faqData.map((faq, index) => (
                  <div 
                    key={index} 
                    data-aos="fade-up" 
                    data-aos-duration={200 + (index * 100)}
                  >
                    <div className="accordion-item">
                      <h2 className="accordion-header">
                        <button
                          className={`accordion-button ${activeIndex === index ? '' : 'collapsed'}`}
                          type="button"
                          onClick={() => handleAccordionClick(index)}
                        >
                          {faq.question}
                        </button>
                      </h2>
                      <div
                        className={`accordion-collapse collapse ${activeIndex === index ? 'show' : ''}`}
                      >
                        <div className="accordion-body">
                          {faq.answer}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
